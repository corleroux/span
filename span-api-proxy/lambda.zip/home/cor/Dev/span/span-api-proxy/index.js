const createApi = require("unsplash-js");
require("dotenv").config();

// console.log(createApi);
// alias worked
const serverApi = createApi.createApi({
  accessKey: process.env.UNSPLASH_ACCESSKEY,
});

const handler = async (event) => {
  // TODO implement

  const response = {
    statusCode: 200,
    body: JSON.stringify(`Hello from Lambda! ${event.key1} ${process.env.UNSPLASH_ACCESSKEY}`),
  };
  return response;
};

module.exports = { handler };
